package cool.compiler;

public class VarDefType {
    public static final String FORMAL = "formal";
    public static final String ATTRIBUTE = "attribute";
}
